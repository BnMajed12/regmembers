<?php

$con=@mysql_connect("127.0.0.1","root","rafa");
$db=@mysql_select_db("vikoba",$con) or die("unknown database");
?>
