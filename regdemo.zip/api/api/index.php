<?php
define('TMSPATH_BASE', dirname(__dir__));

require_once TMSPATH_BASE.'/ext/TMSDatabase.php';
require_once TMSPATH_BASE.'/ext/fileuploader.php';
class Api{
private	$http_data="";

	public function Api(){
	//$this->mycurl("http://masokochallenge.jamaatech.com/api/1.0/category");
   $this->http_data=$_REQUEST;
   $dataz=$this->http_data;
   if(isset($dataz['type'])){
   switch($dataz['type']){
   case 'mikoa':
   echo $this->autoComplete("mikoa","mkoa_id","","","","mkoa","mikoa");
   break;
   case 'wilaya':
   //$parentTable,$parentIdField,$parentSearchField
   echo $this->autoComplete("wilaya","wilaya_id","mikoa","mkoa_id","mkoa","wilaya","wilaya");
   break;
   case 'kata':
    echo $this->autoComplete("kata","kata_id","wilaya","wilaya_id","wilaya","kata","kata");
   break;
   case 'huduma':
   echo $this->autoComplete("huduma_zetu","huduma_id","","","","jina_la_huduma","huduma");
   break;
   case 'mudamalipo':
    echo $this->autoComplete("muda_malipo","id","","","","kwa_maneno","mudamalipo");

   break;
   }
   }
   if(isset($dataz['action'])){
   switch($dataz['action']){
   case 'register':
   $jsonArray=array("jina","jinsia","tarehekuzaliwa","mkoa","wilaya","kata","simu","nambakita","ainakita","mratibu");
   echo $this->registration("mwanachama","id",$jsonArray,"userbasic");
   break;
   case 'register2':
 $jsonArray=array("id","aina","mwanajina","mratibu");
   echo $this->registrationFamily("mwanachama_famili","mwanafamili_id",$jsonArray,"userfamily");
   break;
    case 'register3':
 $jsonArray=array("id","kiwango","kianzio","maliposiku","mudamalipo","huduma","biashara","kikundi","banki","mratibu");
   echo $this->registrationBusiness("maombi_ya_huduma","ombi_id",$jsonArray,"userbusiness");
   break;
   case 'register4':
   echo $this->registrationMdhamini();
   break;
   }
   }
   //$this->login();
   //$this->kosa();
   //$this->ajari();
  // $this->memberRegister();
	}
     private function mycurl($urls){
     // The URL to POST to
     $result="";
  $url = $urls;

  // The value for the SOAPAction: header
  $action = "My.Soap.Action";

  // Get the SOAP data into a string, I am using HEREDOC syntax
  // but how you do this is irrelevant, the point is just get the
  // body of the request into a string
  $mySOAP = <<<EOD
<?xml version="1.0" encoding="utf-8" ?>
<soap:Envelope>
  <!-- SOAP goes here, irrelevant so wont bother writing it out -->
</soap:Envelope>
EOD;

  // The HTTP headers for the request (based on image above)
  $headers = array(
    'Content-Type: text/xml; charset=utf-8',
    'Content-Length: '.strlen($mySOAP),
    'SOAPAction: '.$action
  );

  // Build the cURL session
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  ///curl_setopt($ch, CURLOPT_POST, TRUE);
  //curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  //curl_setopt($ch, CURLOPT_POSTFIELDS, $mySOAP);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

  // Send the request and check the response
  if (($result = curl_exec($ch)) === FALSE) {
    die('cURL error: '.curl_error($ch)."<br />\n");
  } else {
    echo "Success!<br />\n";
  }

  curl_close($ch);
    echo $result;
     }

private function memberRegister(){
$users=$this->http_data;
$db=new TMSDatabase();
$uploader=new fileUploader();
$dates=@date("Y-m-d H:i:s");
if(isset($users['jina']) ){
$jina=$users['jina'];
$mkoa=$users['mkoa'];
$wilaya=$users['wilaya'];
$kata=$users['kata'];
$simu=$users['simu'];
$kikundi=$users['kikundi'];
$biashara=$users['biashara'];
$mkopo=$users['mkopo'];
$tarehemkopo=$users['tarehemkopo'];
$nenosiri=$users['nenosiri'];
$originalfile=$_FILES['picha']['name'];
$tempfile=$_FILES['picha']['tmp_name'];
$error=$_FILES['picha']['error'];
$id=$this->getLastId("members","id")+1;
$filename=$id."_".$jina;
$destpath="";
$myfiles=$uploader->fileProcessor($originalfile,$tempfile,$id,$filename,"images",$error);
if(is_array($myfiles)){
$datainsert=array($id,$jina,$mkoa,$wilaya,$kata,$simu,$kikundi,$biashara,$mkopo,$tarehemkopo,$nenosiri,$dates);
$status=$db->insertField("members",$datainsert);
if($status){
$state=$uploader->insertImageNormal("tze_image","members",$id,"20",$dates,$myfiles[1]);
if($state){
echo "success";
}else{
echo "no image";
}
}else{
echo "not saved";
}
}else{
echo "failed to save image";
}
}else{
echo "no data received";
}

}
	private function login(){
		$data="";
		$login=$this->http_data;
		if(isset($login['login'])){
			$tms_login=new TMSDatabase();
			$mydata=$this->decodeJSON($login['login'],array("userid","pass"),"logins");
			echo $mydata[0][0]."".$mydata[1][0];
			$userid=isset($mydata[0][0])?TMSDatabase::escapeString($mydata[0][0]):"0";
			$password=md5(isset($mydata[0][1])?TMSDatabase::escapeString($mydata[0][1]):"0");
            $status=$tms_login->selectField("police",array("fullname"),"=","police_id",$userid."' and password='".$password,"","","","");
       if($status){
       	$rec=$tms_login->getResultSet();
       	  $data="{'login':[{'userid':'".$userid."','status':'logedin'},";
              $data.="{'userid':'".$ruserid."','status':'logedin'}]}";
              echo $data;
       }
		}else{
			echo "false";
		}
	}

	private function kosa(){
		$kosa=$this->http_data;
		$dates=@date("y-m-d H:i:s");
		$status=false;
      if(isset($kosa['kosa'])){
      	$tms_kosa=new TMSDatabase();
        $mydata=$this->decodeJSON($kosa['kosa'],array("leseni","aina","mahali","gari","maelezo","adhabu","polisi"),"kosa");
        $count=($mydata);
        if($count>0){
        	if(is_array($mydata[0])){
        	for($i=0; $i<$count; $i++){
         $data_to_insert=array("",$mydata[$i][0],$mydata[$i][1],$mydata[$i][2],$mydata[$i][3],$mydata[$i][4],$mydata[$i][5],$mydata[$i][6],$dates);
           $status=$tms_kosa->insertField("driver_kosa",$data_to_insert);
            }
        	}else{
          $data_to_insert=array("",$mydata[0],$mydata[1],$mydata[2],$mydata[3],$mydata[4],$mydata[5],$mydata[6],$dates);
           $status=$tms_kosa->insertField("driver_kosa",$data_to_insert);
        	}
        	 if($status){
           	echo "1";
           }else{
           	echo "0";
           }
        }
      }
	}


/**
*This function is used for autocomplete activities.
*/
private function autoComplete($tablename,$idField,$parentTable,$parentIdField,$parentSearchField,$searchField,$jsontitle){
   $vikoba=$this->http_data;
   $mikoa="";
   $id="";
   $data="";
$searchPart="";
$parentId="";
$mydata="";
$searchvalue="";
$cond="";
$searchFields="";
if(isset($vikoba['action']) && $vikoba['action']=="autocomp"){

$tafutamkoa=new TMSDatabase();
$tojson=isset($vikoba['data'])?$vikoba['data']:"";
if($tojson!=""){

 $mydata=$this->decodeJSON($tojson,array("type","search","value"),$jsontitle);
 if($mydata[0][2]!=""){
  $parentId=$this->pataMkoa($parentTable,$parentSearchField,$mydata[0][2],$parentIdField);

 }
  if($parentId!="" || $parentId!=0){
$searchPart="' and ".$parentIdField."='".$parentId;
if($mydata[0][1]==""){
$searchPart=$parentId;
$searchFields=$parentIdField;
 $cond="=";
// echo "It has some Id ".$parentId;
}

 }else{
 if($mydata[0][1]=="" && $mydata[0][2]!=""){
 $searchFields=$parentIdField;
 $searchPart="10";
 $cond="=";
 //echo "Both it empty type ";
 }
 }

 if($mydata[0][1]!=""){
 $cond="like";
 $searchvalue=$mydata[0][1]."%";
 $searchFields=$searchField;
 }

$status=$tafutamkoa->selectField($tablename,array($idField,$searchField),$cond,$searchFields,$searchvalue.$searchPart,"","","","");
if($status){
$mikoa=array();
$id=array();
while($rec=$tafutamkoa->getResultSet()){
$mikoa[]=$rec[$searchField];
$id[]=$rec[$idField];
}

$data='{"'.$jsontitle.'":[';
$data.='{"'.$jsontitle.'":"Chagua '.$jsontitle.'"},';
for($i=0; $i<count($mikoa); $i++){
if(count($mikoa)!=($i+1)){
$data.='{"'.$jsontitle.'":"'.$mikoa[$i].'","id":"'.$id[$i].'"},';
}else{
$data.='{"'.$jsontitle.'":"'.$mikoa[$i].'","id":"'.$id[$i].'"}]}';
}
}
}
 }
}
if($data!=""){
return $data;
}else{
return '{"'.$jsontitle.'":[{"'.$jsontitle.'":"Chagua '.$jsontitle.'"}]}';
}

  }


  public function arrayToJson($tojson){
  return  json_encode($tojson);
}


public function pataMkoa($tablename,$searchField,$searchValue,$idField){
$id="";
if($searchValue!=""){
$tafutamkoa=new TMSDatabase();
$status=$tafutamkoa->selectField($tablename,array($idField),"=",$searchField,$searchValue,"","","","");
if($status){
$rec=$tafutamkoa->getResultSet();
$id=$rec[$idField];
}
}
return $id;
}

private function pataJinsia($tablename,$idField,$idValue,$jinsiaField){
$jinsia=new TMSDatabase();
$myJinsia="";
$status=$jinsia->selectField($tablename,array($jinsiaField),"=",$idField,$idValue,"","","","");
if($status){
$rec=$jinsia->getResultSet();
$myJinsia=$rec[$jinsiaField];
}
return $myJinsia;
}


private function registrationMdhamini(){
$users=$this->http_data;
$result="";
$db=new TMSDatabase();
$uploader=new fileUploader();
$dates=@date("Y-m-d H:i:s");
if(isset($users['mdhamini']) ){
$jina=$users['mdhamini'];
$simu=$users['mdhaminisimu'];
$id=$mkoa=$users['id'];
$mratibu=$users['mratibu'];
$picha=$_FILES['picha'];
$originalfile_mte=$picha[0]['name'];
$tempfile_mte=$picha[0]['tmp_name'];
$error_mte=$picha[0]['error'];
$originalfile_mdha=$picha[1]['name'];
$tempfile_mdha=$picha[1]['tmp_name'];
$error_mdha=$picha[1]['error'];
$idz=$this->getLastId("mwanachama_mdhamini","mdhamini_id")+1;
$mteja=$this->pataJinsia("mwanachama","jina",$id,"id");
$filename_mte=$id."_".$mteja;
$filename_mdha=$idz."_".$jina;
$destpath="";
$myfiles=$uploader->fileProcessor($originalfile_mte,$tempfile_mte,$id,$filename_mte,"images",$error);
$myfilez=$uploader->fileProcessor($originalfile_mdha,$tempfile_mdha,$idz,$filename_mdha,"images",$error);
if(is_array($myfiles)){
$datainsert=array($idz,$id,$jina,$simu,$mratibu,$simu,$dates);
$status=$db->insertField("mwanachama_mdhamini",$datainsert);
if($status){
$state=$uploader->insertImageNormal("tze_image","mwanachama",$id,"20",$dates,$myfiles[1]);
$states=$uploader->insertImageNormal("tze_image","mwanachama_mdhamini",$idz,"20",$dates,$myfilez[1]);
if($state){
  $result='{"data":[{"refId":"'.$id.'"}]}';
}else{
  $result='{"data":[{"refId":"'.$id.'"}]}';
}
}else{
  $result='{"data":[{"refId":"'.$id.'"}]}';
}
}else{
  $result='{"data":[{"refId":"'.$id.'"}]}';
}
}else{
  $result='{"data":[{"refId":"'.$id.'"}]}';
}
return $result;
}
private function registrationBusiness($tablename,$idField,$jsonArray,$jsonTitle){
 $ajari=$this->http_data;
	 $dates=@date("y-m-d H:i:s");
	 $status=false;
	 $aina="";
	 $id="";
	 $result="";
     if(isset($ajari['action']) ){
     	$tms_ajari=new TMSDatabase();
     	$tms_ajaris=new TMSDatabase();
     	 $mydata=$this->decodeJSON($ajari['data'],$jsonArray,$jsonTitle);
        $count=count($mydata);

        if($count>0){
        $huduma="";
        $muda="";
        	if(is_array($mydata[0])){
        	for($i=0; $i<$count; $i++){
        	// $jsonArray=array("id","kiwango","kianzio","maliposiku","mudamalipo","huduma","biashara","kikundi","banki");
        	$id=$this->getLastId($tablename,$idField)+1;
        	$huduma=$this->pataJinsia("huduma_zetu","jina_la_huduma",$mydata[$i][5],"huduma_id");
        	$muda=$this->pataJinsia("muda_malipo","kwa_maneno",$mydata[$i][4],"id");
         $data_to_insert=array($id,$mydata[$i][0],$huduma,$mydata[$i][1],$mydata[$i][2],$mydata[$i][3],$muda,$dates,$mydata[$i][9]);
           $status=$tms_ajari->insertField($tablename,$data_to_insert);
           $data_to_inserts=array("",$mydata[$i][0],$mydata[$i][7],$mydata[$i][6]);
           $state=$tms_ajaris->insertField("mwanachama_biashara",$data_to_inserts);
            }
        	}else{
        	$id=$this->getLastId($tablename,$idField)+1;
        $huduma=$this->pataJinsia("huduma_zetu","id",$mydata[0],"huduma_id");
        $muda=$this->pataJinsia("muda_malipo","kwa_maneno",$mydata[0],"id");
          $data_to_insert=array($id,$mydata[0],$huduma,$mydata[1],$mydata[2],$mydata[3],$muda,$dates,$mydata[9]);
           $status=$tms_ajari->insertField($tablename,$data_to_insert);

            $data_to_inserts=array("",$mydata[0],$mydata[7],$mydata[6]);
           $state=$tms_ajaris->insertField("mwanachama_biashara",$data_to_inserts);
        	}
        	 if($status){

          $result='{"data":[{"refId":"'.$id.'"}]}';
           }else{
            $result='{"data":[{"refId":"none"}]}';
           }
        }

      }

return $result;
}

private function registrationFamily($tablename,$idField,$jsonArray,$jsonTitle){
 $ajari=$this->http_data;
	 $dates=@date("y-m-d H:i:s");
	 $status=false;
	 $aina="";
	 $id="";
	 $result="";
     if(isset($ajari['action']) ){
     	$tms_ajari=new TMSDatabase();
     	 $mydata=$this->decodeJSON($ajari['data'],$jsonArray,$jsonTitle);
        $count=count($mydata);

        if($count>0){
        $jinsi="";
        	if(is_array($mydata[0])){
        	$jinsi=$this->pataJinsia("mwanachama","id",$mydata[0][0],"jinsia");
        	$isavail=$this->checkAvailable("mwanachama_famili","mwanachama_id",$mydata[0][0]);
        	for($i=0; $i<$count; $i++){
        	$id=$this->getLastId($tablename,$idField)+1;
        	if($mydata[$i][1]=="mke"){
             if($jinsi=="mwanaume"){
        	$aina="mke";
        	}else{
        	$aina="mume";
        	}
        	}else{
        	$aina=$mydata[$i][1];
        	}
        	if(!$isavail){
         $data_to_insert=array($id,$mydata[$i][0],$aina,$mydata[$i][2],$mydata[$i][3]);
           $status=$tms_ajari->insertField($tablename,$data_to_insert);
           }
            }
        	}else{
        	$id=$this->getLastId($tablename,$idField)+1;
        	$jinsi=$this->pataJinsia("mwanachama","id",$mydata[0],"jinsia");
        	$isavail=$this->checkAvailable("mwanachama_famili","mwanachama_id",$mydata[0]);
        	if($mydata[1]=="mke"){
        	if($jinsi=="mwanaume"){
        	$aina="mke";
        	}else{
        	$aina="mume";
        	}
        	}else{
        	$aina=$mydata[1];
        	}
        	if(!$isavail){
          $data_to_insert=array($id,$mydata[0],$aina,$mydata[2],$mydata[3]);
           $status=$tms_ajari->insertField($tablename,$data_to_insert);
           }
        	}
        	 if($status){
          $result='{"data":[{"refId":"'.$id.'"}]}';
           }else{
            $result='{"data":[{"refId":"none"}]}';
           }
        }

      }

return $result;
}

   private function registration($tablename,$idField,$jsonArray,$jsonTitle){
	 $ajari=$this->http_data;
	 $dates=@date("y-m-d H:i:s");
	 $status=false;
	 $id="";
	 $result="";
     if(isset($ajari['action']) ){
     	$tms_ajari=new TMSDatabase();
     	 $mydata=$this->decodeJSON($ajari['data'],$jsonArray,$jsonTitle);
        $count=count($mydata);
        $id=$this->getLastId($tablename,$idField)+1;
        if($count>0){
        	if(is_array($mydata[0])){
        	for($i=0; $i<$count; $i++){
         $data_to_insert=array($id,$mydata[$i][0],$mydata[$i][1],$mydata[$i][2],$mydata[$i][3],$mydata[$i][4],$mydata[$i][5],$mydata[$i][6],$mydata[$i][7],$mydata[$i][8],$mydata[$i][9],$dates);
           $status=$tms_ajari->insertField($tablename,$data_to_insert);
            }
        	}else{
          $data_to_insert=array($id,$mydata[0],$mydata[1],$mydata[2],$mydata[3],$mydata[4],$mydata[5],$mydata[6],$mydata[7],$mydata[8],$mydata[9],$dates);
           $status=$tms_ajari->insertField($tablename,$data_to_insert);
        	}
        	 if($status){
          $result='{"data":[{"refId":"'.$id.'"}]}';
           }else{
            $result='{"data":[{"refId":"none"}]}';
           }
        }

      }

return $result;

     }

public function checkAvailable($tablename,$idField,$idValue){
$last=new TMSDatabase();
    	$counts=false;
    	$status=$last->selectField($tablename,array($idField),"=",$idField,$idValue,"","","","");
    	if($status){
       $counts=true;
    	}
    	return $counts;
}
    public function getLastId($tablename,$indexfield){
    	$last=new TMSDatabase();
    	$counts=0;
    	$status=$last->selectField($tablename,array($indexfield),"","","",$indexfield,"desc","","1");
    	if($status){
        $rec=$last->getResultSet();
        $counts=$rec[$indexfield];
    	}
    	return $counts;
    }

	public function decodeJSON($data,$key_array,$title){
	   $mydata_ob="";
	   $mydata=array();
       $dataobject=json_decode($data);
       if($title!=""){
       $mydata_ob=$dataobject->$title;
      $total=count($mydata_ob);
      for($i=0; $i<$total; $i++){
       for($j=0; $j<count($key_array); $j++){
       	$mydata[$i][$j]=$mydata_ob[$i]->$key_array[$j];
       }}
        }else{
       for($j=0; $j<count($key_array); $j++){
       	$mydata[$j]=$dataobject->$key_array[$j];
       }
        }

       	return $mydata;
	}

}

new Api();

?>
